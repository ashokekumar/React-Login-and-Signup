import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import axios from 'axios';


class Dashboard extends Component {
    constructor(props){
    super(props);
    this.state = {
        projects: [],
      isLoading: true,
      errors: null
    };
    }
      

    componentWillReceiveProps(nextProps){
        console.log("nextProps",nextProps);
      }
    

    //fetch data 
    getProjects(){
        var apiBaseUrl = "http://localhost:4000/api/";
        // We're using axios instead of Fetch
        axios.get(apiBaseUrl+'/project') // The API we're requesting data from   // Once we get a response, we'll map the API endpoints to our props
        .then(response =>
              response.data.data.map(projects => ({
                _id: `${projects.id}`,
                title: `${projects.title}`,
                description: `${projects.description}`,
                cost: `${projects.cost}`,
                currency: `${projects.currency}`
            }))
          
           
          )
          // Let's make sure to change the loading state to display the data
          .then(projects => {
            this.setState({
                projects,
              isLoading: false
            });
          })
          // We can still use the `.catch()` method since axios is promise-based
          .catch(error => this.setState({ error, isLoading: false }));
      }


      componentDidMount() {
        this.getProjects();
      }
    

render() {
    const { isLoading, projects } = this.state;
    return (
      <div>
        <MuiThemeProvider>
        <AppBar
             title="Dashboard"
           />
        </MuiThemeProvider>
        <MuiThemeProvider>
        <div>
       {!isLoading ? (
                projects.map(project => {
                 const { _id,title,description,cost,currency } = project;
                  return (
                    <div key={_id}>
                      <p>{title}</p>
                      <div>
                      <p>{description}</p>
                      </div>
                      <p>{cost} : {currency}</p>
                      <hr />
                    </div>
                  );
                })
              ) : (
                <p>Loading...</p>
              )} 
        </div>
        </MuiThemeProvider>
       
      </div>);
    }
}


    
const style = {
    margin: 15,
  };
  
  export default Dashboard;
  