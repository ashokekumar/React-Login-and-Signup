
const { db_write } = require('../config/db');

const { db_read } = require('../config/db');

function postproject(req, res) {
        
        console.log("project post request received");
        db_write.query('INSERT INTO projects (`title`, `description`, `cost`, `currency`) VALUES (?,?,?,?)',
                    [req.body.title, req.body.description, req.body.cost, req.body.currency],
                    function(err, results) 
                    {
                      
                    if(!err){
                      console.log(results);
                      res.status(200).send({message : "Success"});
                      }else{
                        console.log(err);
                        res.status(400).send({error: 'Error', message : 'record addition failed'});
                      }
                    }
                  );     
 }


 function showprojects(req, res){
  db_read.query('SELECT  `id`, `title`, `description`, `cost`, `currency` FROM projects',[],
    (err, response, fields) => {
    if(!err && response.length >= 1){    
      const project = response[0];
      res.status(200).json({
        message: "success",
        data: response
    });
 }else {
  res.status(401).send({error: err, message : ' failed'});
}
}

);
}

module.exports = {  postproject,showprojects };