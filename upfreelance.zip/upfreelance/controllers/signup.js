
const { db_write } = require('../config/db');
const config = require('../config/app');
const jwt = require('jsonwebtoken')
const Hash = require('crypto-js/pbkdf2');

function signup(req, res) {
    
  // var data = req.body.email +": "+req.body.username +": "+req.body.password +":"+req.body.confirmationPassword;
    
    if(req.body.password != req.body.confirmationPassword){
        res.status(204).send({error: 'Password mismatch', message : 'Password match failed'});
    }else{
        const encpassword = Hash(req.body.password, config.appSecret).toString();
        db_write.query('INSERT INTO users (`username`, `first_name`, `last_name`, `email`, `enabled`, `password`,`experiencetype`,`worktype`)VALUES (?,?,?,?,?,?,?,?)',
                    [req.body.username, req.body.firstname, req.body.lastname, req.body.email, 1, encpassword,req.body.experiencetype, req.body.worktype],
                    function(err, results) 
                    {
                    if(!err){
                      console.log(results);
                      res.status(200).send({message : "Success"});
                      }else{
                        res.status(400).send({error: 'Error', message : 'record addition failed'});
                      }
                    }
                  );     
 }
}



module.exports = {  signup };