const express = require('express');
const router = express.Router();
const auth = require('../controllers/auth');
const signup = require('../controllers/signup');
const project = require('../controllers/project');
const validate = require('express-validation');
const authValidation = require('../validations/auth')

router.route('/auth/login').post(validate(authValidation.loginParam), auth.login);
router.route('/auth/logout').get(auth.logout);
router.route('/signup').post(signup.signup);
router.route('/project').post(project.postproject);
router.route('/project').get(project.showprojects);

module.exports = router;