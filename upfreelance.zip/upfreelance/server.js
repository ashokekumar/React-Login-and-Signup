const express = require('express');
const session = require('express-session');
const cors = require('cors');
const config = require('./config/app.js');
const compression = require('compression');
const routes = require('./routes');
const errorHandler = require('express-json-errors');
const middlewareErrorParser = require('./middleware/ErrorParser');
const middlewarePathLogger = require('./middleware/PathLogger');

const app = express();

app.use(session({secret: 'secretkey',saveUninitialized: true,resave: true}));
app.use(express.json({type: "application/json"}));
app.use(express.urlencoded({ extended: false }));

// add cors headers
app.use(cors());

// comporess output
app.use(compression());

// only on debug mode
if(config.debug){
    // path logger
    app.use(middlewarePathLogger);
}

// use routes
app.use('/api/', routes);

app.use(middlewareErrorParser);

// Start server
app.listen(config.port, () => {
  console.log('Express server listening on %d, in %s mode', config.port, app.get('env'));
});

// Expose app
module.exports = app;